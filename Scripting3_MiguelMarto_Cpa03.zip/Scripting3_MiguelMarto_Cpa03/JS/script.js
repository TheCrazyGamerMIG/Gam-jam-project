document.addEventListener('DOMContentLoaded', function() {
    //Function to create a button
    function createButton(text, link) {
        const button = document.createElement('button');
        button.textContent = text;
        button.onclick = function() {
            window.location.href = link;
        };
        return button;
    }

    //Buttons for each webpage
    const aboutButton = createButton('About page', 'about.html');
    const projectButton = createButton('Project Showcase Page', 'project.html');
    const contactButton = createButton('Contact Page', 'contact.html');

    //Attaches the buttons to the body
    document.body.appendChild(aboutButton);
    document.body.appendChild(projectButton);
    document.body.appendChild(contactButton);
});

/*
References
Title: Chat Gpt
Author: Open A.I
Date Accessed: 26 May 2024
Availability: https://chatgpt.com/c/6553e57c-b318-4e1c-addb-6cd462bce395
*/